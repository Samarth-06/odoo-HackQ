
  # Enterprise Dashboard UI Design

 

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
